/* global marked, hljs, CodeMirror, saveAs */

marked.setOptions({
    langPrefix: 'hljs',
    highlight: function(code) {
        return hljs.highlightAuto(code).value;
    }
});

function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]);
    return null;
}
var newi=0;
var parsedata = function(jd) {
    var postparam1 = {};
    var newtype = new Array();
	var postparam = new Array();
    var type = '';
    if (jd.match('^\{(\".+\":.+,*){1,}\}$')) {
        var jdd = JSON.parse(jd);
		var getKey =function(jdd, depth) {
        if (newi > depth) {
			newi=0;
            return
        }
        newi++;
        for (var ddd in jdd) {
            if (isNaN(ddd)) {
                postparam1[ddd] = 1;
            }
            if (jdd[ddd] instanceof Object) {
                getKey(jdd[ddd], depth);
            }
        }
    }
        getKey(jdd,15);
		for(var ki in postparam1) {
			postparam.push(ki)
		}
        type = 'json';
    } else if (isXML(jd)) {
        postparam = jd;
        type = 'xml';
    } else {
        console.log('otherother');
        postparam = UrlSearch("?" + jd);
        type = 'other';
    }
    newtype["type"] = type;
    newtype["postparam"] = postparam;
    return newtype;
}

    function getKey(jdd, depth,postparam) {
        if (newi > depth) {
			newi=0;
            return
        }
        newi++;
        for (var ddd in jdd) {
            if (isNaN(ddd)) {
                postparam[ddd] = 1;
            }
            if (jdd[ddd] instanceof Object) {
                getKey(jdd[ddd], depth);
            }
        }
    }

function UrlSearch(str) {
    var name, value;
    var num = str.indexOf("?")
    str = str.substr(num + 1); //取得所有参数   stringvar.substr(start [, length ]

    var arr = str.split("&"); //各个参数放到数组里
    var newarr = new Array();
    for (var i = 0; i < arr.length; i++) {
        num = arr[i].indexOf("=");
        if (num > 0) {
            name = arr[i].substring(0, num);
            value = arr[i].substr(num + 1);
            newarr[name] = value;
        }
    }
    return newarr;
}
var isXML = function(elem) {
    var documentElement = (elem ? elem.ownerDocument || elem : 0).documentElement;
    return documentElement ? documentElement.nodeName !== "HTML" : false;
};
var formatstr = function(str) {
    var ss = '';
    if (str.match('^\{(\".+\":.+,*){1,}\}$')) {
        try {
            ss = vkbeautify.json(str, 4);
        } catch (e) {
            ss = str;
        }
    } else if (isXML(str)) {
        try {
            ss = vkbeautify.xml(str);
        } catch (e) {
            ss = str;
        }
    } else {
        ss = str;
    }
    return ss;
}
$(function() {
    var storageKey = 'markdoc',
        storageNameKey = 'markdocName',
        lastValue,
        mode = 'gfm',
        editor = $('#editor'),
        storageValue = localStorage.getItem(storageKey) || $.trim($('#readme').html());
    if (storageValue) {
        editor.val(storageValue);
    }
    //
    var w = GetQueryString("w");
    if (w != null) {
        var word = sessionStorage.getItem(w);
        if (word != null) {
            dw = JSON.parse(word);
            var getparam = new Array();
            var postparam = new Array();
            var postdata = new Array();
            if (dw.url != "") {
                console.log(dw.url);
                getparam = UrlSearch(dw.url);
            }
            if (dw.parms != "") {
                var jd = dw.parms;

                postdata = parsedata(jd);

                postparam = postdata["postparam"];
            }

            var md = "\n\n";
            md += "## 接口名称";
            md += "\n\n";
            md += '### 1) 请求地址';
            md += "\n\n";
            md += ">" + dw.url;
            md += "\n\n";
            md += "### 2) 调用方式：HTTP " + dw.seltype;
            md += "\n\n";
            md += "### 3) 接口描述：";
            md += "\n\n";
            md += "* 接口描述详情";
            md += "\n\n";
            md += "### 4) 请求参数:";
            md += "\n\n";

            var getpp = '';

            for (var ii in getparam) {
                getpp += "|" + ii + "||string|Y|-|";
                getpp += "\n";
            }
            var postpp = '';
            for (var ii in postparam) {
                postpp += "|" + ii + "||string|Y|-|";
                postpp += "\n";
            }
            if (postdata["type"] == "xml" || postdata["type"] == "json") {
                md += "\n\n";
                md += "```";
                md += "\n";
                md += formatstr(dw.parms);
                md += "\n";
                md += "```";
                md += "\n";
            }
            if (getpp.length > 0) {
                md += "#### GET参数:";
                md += "\n";
                md += "|字段名称       |字段说明         |类型            |必填            |备注     |";
                md += "\n";
                md += "| -------------|:--------------:|:--------------:|:--------------:| ------:|";
                md += "\n";
                md += getpp;
                md += "\n";
            }
            if (postdata["type"] != "xml") {
                if (postpp.length > 0) {
                    md += "\n";
                    md += "#### POST参数:";
                    md += "\n";
                    md += "|字段名称       |字段说明         |类型            |必填            |备注     |";
                    md += "\n";
                    md += "| -------------|:--------------:|:--------------:|:--------------:| ------:|";
                    md += "\n";
                    md += postpp;
                    md += "\n";
                }
            }

            md += "\n\n";
            md += "### 5) 请求返回结果:";
            md += "\n\n";
            md += "```";
            md += "\n";
            md += formatstr(dw.result);
            md += "\n";
            md += "```";
            md += "\n";
            md += "\n\n";

            postresult = parsedata(dw.result);
            if (postresult["type"] == 'json') {
                md += "### 6) 请求返回结果参数说明:";

                pr = postresult["postparam"];
                var repp = '';
                for (var ii in pr) {
                    repp += "|" + pr[ii] + "||string|Y|-|";
                    repp += "\n";

                }
                if (repp.length > 0) {
                    md += "\n";
                    md += "|字段名称       |字段说明         |类型            |必填            |备注     |";
                    md += "\n";
                    md += "| -------------|:--------------:|:--------------:|:--------------:| ------:|";
                    md += "\n";
                    md += repp;
                    md += "\n";
                }
            }
            if (2 == 1) {
                ssssss = editor.val();
                md += "\n\n";
                md += ssssss;
            }
            editor.val(md);
        }

    }
    //
    var mirror = CodeMirror.fromTextArea(editor[0], {
        mode: mode,
        cursorHeight: 1,
        lineNumbers: true,
        lineWrapping: true,
        styleActiveLine: true
    });
    mirror.focus();
    var $iframe = $('iframe'),
        iframeWin = $iframe[0].contentWindow,
        $iframeWin = $(iframeWin),
        $iframeDoc = $(iframeWin.document),
        preview,
        handler,
        editorScrolling,
        previewScrolling,
        timeout = 500;
    mirror.on('change', function(mirror) {
        clearTimeout(handler);
        handler = setTimeout(render, timeout);
    });
    mirror.on('scroll', function(mirror) {
        if (previewScrolling) {
            previewScrolling = false;
            return;
        }
        editorScrolling = true;
        getPreview();
        var info = mirror.getScrollInfo();
        var top = (preview.outerHeight() - info.clientHeight) *
            info.top / (info.height - info.clientHeight);
        iframeWin.scrollTo(0, top);
    });
    $iframeWin.on('scroll', function() {
        if (editorScrolling) {
            editorScrolling = false;
            return;
        }
        previewScrolling = true;
        getPreview();
        var info = mirror.getScrollInfo();
        var top = (info.height - info.clientHeight) *
            $iframeWin.scrollTop() / (preview.outerHeight() - info.clientHeight);
        mirror.scrollTo(0, top);
    });

    function getPreview() {
        if (!(preview && preview.length > 0)) {
            preview = $(iframeWin.document).find('#container');
        }
    }

    function render(e) {
        // console.log(e);
        var value = mirror.getDoc().getValue();
        if (value === lastValue) {
            return;
        }
        lastValue = value;
        iframeWin.render(marked(value));
        localStorage.setItem(storageKey, value);
    }

    if (window._previewLoaded) {
        render('preview load before');
    } else {
        window.previewLoaded = function() {
            render('preview load');
        };
    }

    var inputName = $('#input-name');
    var storageName = localStorage.getItem(storageNameKey);
    if (storageName) {
        inputName.val(storageName);
    }
    inputName.change(function() {
        localStorage.setItem(storageNameKey, inputName.val());
    });

    function getName(ext) {
        return (inputName.val() || 'mark') + ext;
    }

    $('#btn-md').click(function() {
        var content = mirror.getDoc().getValue();
        var blob = new Blob([content], { type: 'text/x-markdown;charset=utf-8' });
        saveAs(blob, getName('.md'));
    });

    function download(ext, type) {
        var doc = iframeWin.document,
            head = doc.head,
            links = $(head).find('link'),
            ajaxes = [],
            text = [];
        links.each(function(i) {
            ajaxes.push($.ajax({
                url: this.href
            }));
        });
        $.when.apply($, ajaxes).done(function() {
            for (var i = 0; i < arguments.length; i += 1) {
                text.push(arguments[i][0]);
            }
            var content = iframeWin.document.body.parentNode.outerHTML;
            if (content.charAt(1) !== '!') {
                content = '<!doctype html>' + content;
            }
            // Replace external styles with inline <style>
            content = content.replace(/(<link[^>]*>\s*(<\/link>)?\s*)+/, '<style type="text/css">' + text.join('\n') + '</style>');
            // Remove scripts
            content = content.replace(/<script[^>]*>[\s\S]*?<\/script>\s*/g, '');
            var blob = new Blob([content], { type: type });
            saveAs(blob, getName(ext));
        });
    }

    $('#btn-doc').click(function() {
        download('.doc', 'application/msword');
    });

    $('#btn-html').click(function() {
        download('.html', 'text/html;charset=utf-8');
    });

    $('#btn-pdf').click(function() {
        alert("请在chrome浏览器中操作,你将打开一个新页面，在新页面里点击右键=>打印，选择保存pdf");
        var $iframe = $('iframe');
        iframeWin = $iframe[0].contentWindow;
        var win = window.open("", "", "fullscreen");
        var doc = win.document;
        doc.write(iframeWin.document.body.parentNode.outerHTML);
        doc.close();
    });

    var db;
    const DB_TABLE = 'markdown';
    window.indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB;
    if (window.indexedDB) {
        try {
            var request = window.indexedDB.open('MD', 6);

            request.onupgradeneeded = function(event) {
                db = event.target.result;
                var objectStore = db.createObjectStore(DB_TABLE, { keyPath: "id", autoIncrement: true });
                objectStore.createIndex("md5", "md5", { unique: true });
                objectStore.createIndex("t", "t", { unique: false });
            }
            request.onsuccess = function(event) {
                db = event.target.result;
            };

        } catch (e) {
            console.log(e)
        }
        $("#btn-savemd").click(function() {
            var mdsaveid = $("#md_save_id").val();
            var mdsaveidid = $("#md_save_id_id").val();
            var md_save_id_md5 = $("#md_save_id_md5").val();
            if (mdsaveid == '') {
                alert('请输入保存的名称');
                return false;
            }
            var mdcontent = mirror.getValue();
            var t = new Date().getTime();
            var mdname = md5(mdsaveid + t);
            try {
                var transaction = db.transaction([DB_TABLE], 'readwrite');
                var objectStore = transaction.objectStore(DB_TABLE);
                if (mdsaveidid == "") {
                    var addRec = objectStore.add({ t: t, md5: mdname, mdcontent: mdcontent, name: mdsaveid });
                    addRec.onsuccess = function(event) {
                        id = event.target.result;
                        $("#md_save_id_id").val(id);
                        $("#md_save_id_md5").val(mdname);
                        $("#btn-savemd").text("更新到浏览器");
                        $("#btn-createmd").show();
                    }
                    addRec.onerror = function(event) {
                        console.log(event)
                    }
                } else {
                    console.log(mdcontent);
                    console.log(mdsaveid);
                    var index = objectStore.index("md5");
                    index.get(md_save_id_md5).onsuccess = function(event) {
                        employee = event.target.result;
                        if (typeof(employee) != "undefined") {
                            employee.t = new Date().getTime();
                            employee.mdcontent = mdcontent;
                            employee.name = mdsaveid;
                            db.transaction([DB_TABLE], "readwrite").objectStore(DB_TABLE).put(employee);
                        }
                    }


                }

            } catch (e) {
                console.log(e)
            }
        });
        $("#btn-mdhistory").click(function() {
            var aid = $("#btn-mdhistory").attr('aid');;
            if (aid == 1) {
                $("#mdhistory").slideUp("slow");

                $("#btn-mdhistory").text('显示保存记录');
                $("#btn-mdhistory").attr('aid', 0);
            } else {
                $("#history").html('');
                $("#mdhistory").slideDown("slow");
                var transaction = db.transaction([DB_TABLE], 'readonly');
                var objectStore = transaction.objectStore(DB_TABLE);
                var index = objectStore.index("t");
                console.log(index);
                tt = (new Date().getTime()) - 86400 * 10 * 1000
                    //var range = IDBKeyRange.lowerBound(tt);
                di = 0;
                index.openCursor(null, "prev").onsuccess = function(event) {
                    if (di < 200) {
                        var cursor = event.target.result;
                        var flag = 0;
                        if (cursor) {
                            // console.log(cursor.key);
                            // console.dir(cursor.value.url);
                            addHistory("append", cursor.value.md5, cursor.value.mdcontent, cursor.value.name, cursor.value.id)
                            cursor.continue();
                        }
                    } else {
                        return;
                    }
                    di++;
                };
                $("#btn-mdhistory").text('隐藏保存记录');
                $("#btn-mdhistory").attr('aid', 1);
            }

        });

        var addHistory = function(addr, md5, mdcontent, name, id) {
            if (addr == "append") {
                $("#history").append("<tr><td style='overflow:hidden'><a class='addmkdown' name='" + name + "' aid='" + id + "' md5='" + md5 + "' mdcontent='" + mdcontent + "' >" + name + "</a></td><td class='deltd'  aid='" + id + "' title='删除'><a>X</a></td></tr>");
            }
        }
        $(document).on("click", '.addmkdown', function() {
            var mdcontent = $(this).attr("mdcontent");
            console.log($(this).attr("name"));
            $("#md_save_id").val($(this).attr("name"));
            $("#md_save_id_id").val($(this).attr("aid"));
            $("#md_save_id_md5").val($(this).attr("md5"));
            $("#btn-savemd").text("更新到浏览器");
            $("#btn-createmd").show();
            // console.log(mdcontent);
            mirror.setValue(mdcontent);
            //$('#editor').val(mdcontent);
        });

        $(document).on("click", '.deltd', function() {
            var aid = $(this).attr("aid");
            aid = parseInt(aid);
            var ret = db.transaction([DB_TABLE], "readwrite").objectStore(DB_TABLE).delete(aid);
            ret.onerror = function(event) {}
            ret.onsuccess = function(event) {}
            $(this).parents("tr").hide();
        });

        $("#btn-createmd").click(function() {
            $("#md_save_id_id").val('');
            $("#md_save_id_md5").val('');
            $("#md_save_id").val('');
            mirror.setValue('');
            $("#btn-createmd").hide();
            $("#btn-savemd").text("保存到浏览器");
        });
    }
    var isFileSaverSupported;
    try {
        isFileSaverSupported = !!new Blob();
    } catch (e) {}
    if (!Array.prototype.forEach) {
        $('.tools').append(' 注意：你的浏览器不支持预览和下载，请使用 chrome 等现代浏览器。');
    } else if (!isFileSaverSupported) {
        $('.tools').append(' 注意：你的浏览器不支持下载，请使用 chrome 等现代浏览器。');
    }
});