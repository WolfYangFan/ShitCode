if(Math.floor(Math.random() * 2)==1){
    var x = [6,8,10,6,8,13,13];
}else{
    var x = [6,6,11,11,13,13,11];
}
window.onload=function(){
    for(i=1;i<8;i++){
        document.getElementById("v"+i).value = x[i-1];
    }
}
function loop7(i){
    if(i<7){
        i++;
        var delay = parseInt(document.getElementById("rp"+i).alt);
        setTimeout(() => {
            repeaterOn(i);
            playThisnote(i);
            loop7(i);
        }, (delay+1)*100);
        setTimeout(() => {
            repeaterOff(i);
        }, (delay+9)*100);
    }
}
function playThisnote(i){
    var pitch = document.getElementById("v"+i).value;
    var audio = "audios/"+pitch+".ogg";
    var c = new Audio(audio);
    c.play();
}
function repeaterOn(i){
    var delay = parseInt(document.getElementById("rp"+i).alt);
    document.getElementById("r"+i).innerHTML = '<img id="rp'+i+'" src="pictures/repeater_on_'+delay+'.png" alt="'+delay+'" onclick="add_repeater('+i+')" height="80" width="80">';
}
function repeaterOff(i){
    var delay = parseInt(document.getElementById("rp"+i).alt);
    document.getElementById("r"+i).innerHTML = '<img id="rp'+i+'" src="pictures/repeater_'+delay+'.png" alt="'+delay+'" onclick="add_repeater('+i+')" height="80" width="80">';
}
function add_note(n){
    var pitch = parseInt(document.getElementById("v"+n).value,10);
    if (pitch>=0 && pitch<24){
        pitch++;
    }else{
        pitch = 0;
    }
    var audio = "audios/"+pitch+".ogg";
    var c = new Audio(audio);
    c.play();
    document.getElementById("v"+n).value = pitch;
}
function add_repeater(n){
    var delay = parseInt(document.getElementById("rp"+n).alt);
    delay = (delay+1)%4;
    document.getElementById("r"+n).innerHTML = '<img id="rp'+n+'" src="pictures/repeater_'+delay+'.png" alt="'+delay+'" onclick="add_repeater('+n+')" height="80" width="80">';
}
