

function decodeUrlRequest() {
  return new Promise((resolve, reject) => {
    let query = getUrlkey(window.location.href);
    console.log(query,'query')
    let data = {
      encryptionInviteCode: query.inviteCode
    }
    $axios.get(`/link/decodeControlInviteCode`, {params: data})
      .then(res => {
        resolve(res.data)
      })
      .catch(err => {
        console.error(err);
      })
  })
} 