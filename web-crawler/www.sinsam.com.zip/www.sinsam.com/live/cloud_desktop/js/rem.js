!function(e, t) {
  
  var n = t.documentElement,
  d = e.devicePixelRatio || 1;
  var MAXW = 476;
  var isWxwork = /wxwork/i.test(navigator.userAgent)
  var isMobile = /iphone|android/i.test(navigator.userAgent)
  if(isWxwork){
    MAXW = 360
  }
  function i() {
	var w = n.offsetWidth;
    var e = w / 3.75;
    n.style.fontSize = e + "px"
    if (!isMobile || (isWxwork && !isMobile)) {
      n.style.fontSize = (MAXW / 3.75) + "px";
      if (isMobile) {
        n.style.margin = '0 auto';
        n.style.width = MAXW + "px";
      }
    }
  }
  if (function e() {
    t.body ? t.body.style.fontSize = "14px": t.addEventListener("DOMContentLoaded", e)
  } (), i(), e.addEventListener("resize", i), e.addEventListener("pageshow",
  function(e) {
    e.persisted && i()
  }), 2 <= d) {
    var o = t.createElement("body"),
    a = t.createElement("div");
    a.style.border = ".5px solid transparent",
    o.appendChild(a),
    n.appendChild(o),
    1 === a.offsetHeight && n.classList.add("hairlines"),
    n.removeChild(o)
  }
}(window, document)