
// 函数防抖  重新重新计算时间,在经过指定的间隔内没有输入的情况下才会调用函数方法  用于不逐字触发搜索请求
function _debounce (fn, delay) {
  delay = delay || 300
  var timer
  return function () {
    var th = this
    var args = arguments
    if (timer) {
      clearTimeout(timer)
    }
    timer = setTimeout(function () {
      timer = null
      fn.apply(th, args)
    }, delay)
  }
}

// 函数节流 在规定的时间间隔呢，重复触发函数，只有一次是成功调用   用于鼠标事件 
function _throttle (fn, delay) {
  var lastTime
  var timer
  delay = delay || 200
  return function () {
    var args = arguments
    // 记录当前函数触发的时间
    var nowTime = Date.now()
    if (lastTime && nowTime - lastTime < delay) {
      clearTimeout(timer);
      timer = setTimeout(function () {
        // 记录上一次函数触发的时间
        lastTime = nowTime
        // 修正this指向问题
        fn.apply(this, args)
      }, delay)
    } else {
      lastTime = nowTime
      fn.apply(this, args)
    }
  }
}
