var webrtcconn = null;
var remoteVideo = null; 
var binpressedclick = false;//表示是否在被按压后松开的那一次click
var isFullScreen = false    //是否为全屏状态
var mouseVideoWidth = null
var mouseVideoHeight = null

var pressCount = 0
var releaseCount = 0

//单击或者双击 左键还是右键  也可拆分
function MouseClickDef(status,bleft) {
    let obj = new Object();
    obj.msgtype = "mouseClick";
    obj.status = status//single pr double 
    obj.left = bleft;//true or false 
    return obj;
}
//拖动例子  先发按下
//最后发松开 完成拖动
function MousePressLooseDef(status,bleft) {
    let obj = new Object();
    obj.msgtype = "mousePress";
    obj.left = bleft;
    obj.status = status//pressed or released
    
    return obj;
}
//鼠标位置
function MousePositionDef(x, y) {
    let obj = new Object();
    obj.msgtype = "mouseMove";
    obj.x = x;
    obj.y = y;
    return obj;
}

function setupMouseEvent(conn, videoel) {
    webrtcconn = conn;
    remoteVideo = videoel;
    remoteVideo.addEventListener('canplay', function () {
        mouseVideoWidth = remoteVideo.clientWidth;
        mouseVideoHeight = remoteVideo.clientHeight;
    });
    window.onresize = function() {
        mouseVideoWidth = remoteVideo.clientWidth;
        mouseVideoHeight = remoteVideo.clientHeight;
        console.log(mouseVideoWidth,mouseVideoHeight)
    }
    document.onmousedown = function(event) {
        console.log("mouse down");
        let e = event || window.event || arguments.callee.caller.arguments[0];
        e.preventDefault();  //阻止默认事件
        let msg = null
        if (e.button == 2) {    
            //鼠标右键
            msg = new MousePressLooseDef("pressed", false);
        }else if (e.button == 0) {
            //鼠标左键
            msg = new MousePressLooseDef("pressed", true);
        }    
        pressCount = pressCount + 1
        msg.pressCount = pressCount 
        if(binvideoElemRange) {
            webrtcconn.sendMessage(msg);
        }
    };
    document.onmouseup = function(event) {
        console.log("mouse up");
        let e = event || window.event || arguments.callee.caller.arguments[0];
        e.preventDefault();  //阻止默认事件
        if (e.button == 2) {    
            //鼠标右键
            msg = new MousePressLooseDef("released", false);
        }else if (e.button == 0) {
            //鼠标左键
            msg = new MousePressLooseDef("released", true);
        }
        releaseCount = releaseCount + 1
        msg.releaseCount = releaseCount
        if(binvideoElemRange) {
            webrtcconn.sendMessage(msg);
        };
        binpressedclick=true;
    };
    remoteVideo.onmouseout = function(event) {	
//         console.log("出去");
        binvideoElemRange = false;
    }
    remoteVideo.onmouseover = function(event) {	
//         console.log("进来");
        binvideoElemRange = true;
    }
    remoteVideo.onclick = function(event) {
        
        let e = event || window.event || arguments.callee.caller.arguments[0];
        e.preventDefault();  //阻止默认事件
        let msg = new MouseClickDef("single", true);
        console.log(binpressedclick, binvideoElemRange)
        if(!binpressedclick&&binvideoElemRange) {
            webrtcconn.sendMessage(msg);
            console.log(msg,'123')
            
        }else{
            //console.log("忽略这一次click");
            binpressedclick=false;
        }
    };
    remoteVideo.oncontextmenu = function(event) {
        //右键菜单事件
        let e = event || window.event || arguments.callee.caller.arguments[0];
        e.preventDefault();  //阻止默认事件
        let msg = new MouseClickDef("single", false);
        if(!binpressedclick&&binvideoElemRange) {
            return webrtcconn.sendMessage(msg);
        }else{
            //console.log("忽略这一次click");
            binpressedclick=false;
        }
    }
    remoteVideo.ondblclick = function(event) {
        let e = event || window.event || arguments.callee.caller.arguments[0];
        e.preventDefault();  //阻止默认事件
        let msg = new MouseClickDef("double", true);
        if(binvideoElemRange) {
            webrtcconn.sendMessage(msg);
        };
    };
    remoteVideo.onmousemove = function(event) {
        let e = event || window.event || arguments.callee.caller.arguments[0];
        e.preventDefault();  //阻止默认事件
        let msg = null
        
        // console.log(controlBox._data,'controlBox._data.videoHeight')
        if (!controlBox._data.videoHeight && !controlBox._data.videoWidth) {
           
        }else {
            mouseVideoWidth = controlBox._data.videoWidth;
            mouseVideoHeight = controlBox._data.videoHeight
        }
        // console.log(isFullScreen,'isFullScreen')
        if (isFullScreen) {
            let width = window.innerWidth
            || document.documentElement.clientWidth
            || document.body.clientWidth;
            let height = window.innerHeight
            || document.documentElement.clientHeight
            || document.body.clientHeight;
            msg = new MousePositionDef((( e.offsetX)/width * 100), ((e.offsetY)/height * 100));
        }else {
            console.log(e.offsetX,remoteVideo.offsetLeft, mouseVideoWidth)
            msg = new MousePositionDef((( e.offsetX - remoteVideo.offsetLeft)/mouseVideoWidth * 100), ((e.offsetY - remoteVideo.offsetTop)/mouseVideoHeight * 100));
        }
        if(binvideoElemRange) {
            webrtcconn.sendMessage(msg);
        };
    };
    

}

document.addEventListener("fullscreenchange", function (e) {
    if (document.fullscreenElement) {
        isFullScreen = true
    } else {
        isFullScreen = false
    }
  })
  

function clearMouseEvent(videoel) {
    remoteVideo = videoel;
    webrtcconn = null
    document.onmousedown = null
    document.onmouseup = null
    remoteVideo.onmouseout = null
    remoteVideo.onmouseover = null
    remoteVideo.onclick = null
    remoteVideo.oncontextmenu = null
    remoteVideo.ondblclick = null
    remoteVideo.onmousemove = null
}

function checkFull(ele){
    var isFull = ele.fullscreenEnabled || ele.fullScreen || ele.webkitIsFullScreen || ele.msFullscreenEnabled;
    if(isFull === undefined) isFull = false;
    return isFull;
}