

function assert(condition) {
    if (!condition) {
        alert('assert');
    }
}

function logDebug(log) {
    console.info(log);
}

function logError(log) {
    console.error(log);
    // alert(log);
}

function VLinkConnection(url1, uid) {
    // private：
    var websocket_ = null; 
    var url = url1;
    var requestId_ = 0;
    var _this = this;
    var pingTimeoutCount_ = 0;
    var pingTimerId_ = setInterval(function() {
        pingTimeoutCount_++;
        if (pingTimeoutCount_ > 3) {
            logError("websocket ping count > 3, close it");
            destroyResource();
        }
    }, 3000);

    // public：
    this.onOpen = null;
    this.onMessage = null;
    this.onClose = null;
    this.onRejected = null;

    var destroyResource = function() {
        if (websocket_ != null) {
            websocket_.close();
            websocket_ = null;
        }
        if (pingTimerId_ != 0) {
            clearInterval(pingTimerId_);
            pingTimerId_ = 0;
        }
        if (_this.onClose != null) {
            _this.onClose();
            _this.onClose = null;
        }
    }

    this.close = function() {
        _this.onClose = null;
        destroyResource();
    }

    this.sendMessage = function(type, message) {
        if (websocket_ == null) {
            logError("websocket is null"); 
            return false;
        }
        if (!websocket_.isConnected) {
            assert(websocket_.buffer != null);
            websocket_.buffer.push({'type' : type, 'message' : message});
            return;
        }
        message['type'] = type;
        message['requestId'] = ++requestId_;
        var data = {
            'data' : message,
            'bid': 'vstream',
            'aid': 'remotedesktop'
        };
        var msg = JSON.stringify(data);
        console.log("发送消息:",msg);
        websocket_.send(msg);
    }
    var init = function(url) {
        assert(websocket_ == null);
        websocket_ = new WebSocket(url);
        websocket_.isConnected = false;
        websocket_.buffer = [];
        websocket_.onopen = function() {
            logDebug("websocket opened...");
            assert(_this.onOpen != null);
            websocket_.isConnected = true;
            for (var i = 0; i < websocket_.buffer.length; i++) {
                _this.sendMessage(websocket_.buffer[i]['type'], websocket_.buffer[i]['message']);
            }
            websocket_.buffer = null;
            _this.onOpen();
        };
        websocket_.onmessage = function (evt) { 
            pingTimeoutCount_ = 0;
            var message = JSON.parse(evt.data);
            console.log(evt.data,'123')
            if (message["category"] == null) {
                logError("category is null");
                return;
            }
            if (message["type"] == null) {
                logError("type is null");
                return;
            }
            if (message["category"] == 0 && message["type"] == 0) {
                if (message["data"] == null) {
                    logError("data is null");
                    return;
                }
                if (message["data"]["type"] == null) {
                    logError("data type is null");
                    return;
                }
                var data = message["data"];
                if (data.rescode==1) {
                    controlBox._data.loadingText = data.errmsg
                    _this.onRejected();
                }
                _this.onMessage(message["data"]["type"], message["data"]);
            }else if(message["category"] == 1 && message["type"] == 9) {
                controlBox._data.loadingText = '当前链接已有其他用户正在远程'
                logError("rejected");
                _this.onRejected();
            }
            
            assert(_this.onMessage != null);
            _this.onMessage(evt.data);
        };
        websocket_.onclose = function() { 
            // 关闭 websocket
            logError("websocket closed..."); 
            websocket_ = null;
            destroyResource();
        };
    }
    init(url);
}

function VStreamConnection(url, uid) {
    // private:
    var url_ = url;
    var uid_ = uid;
    var connection_ = null;
    var isJoin_ = false;
    var this_ = this;
    // public:
    this.onClose = null;
    this.onJoin = null;
    this.onUserJoin = null;
    this.onUserLeave = null;
    this.onSendMessage = null;
    this.onMessage = null;
    this.close = function() {
        if (connection_ != null) {
            connection_.close();
            connection_ = null;
        }
    }
    this.join = function() {
        assert(connection_ == null);
        connection_ = new VLinkConnection(url_, uid_);
        connection_.onOpen = function() {
        }
        connection_.onClose = function() {
            console.log("vlink is close")
            assert(this_.onClose != null);
            this_.onClose();
            this_.onClose = null;
        }
        connection_.onMessage = function(type, message) {
            if (type == "JoinResponse") {
                if (isJoin_) {
                    logError("join failed, isJoin_ is true");
                    return;
                }
                isJoin_ = true;
                if (message.rescode != 0) {
                    destroy(message.rescode, message.errmsg);
                    return;
                }
                assert(this_.onJoin != null);
                this_.onJoin();
            } else if (type == "UserJoinNotify") {
                assert(this_.onUserJoin != null);
                this_.onUserJoin(message["uid"]);
            } else if (type == "UserLeaveNotify") {
                assert(this_.onUserLeave != null);
                this_.onUserLeave(message["uid"]);
                // TODO：subscribeUsers_.erase(notify.uid); 
            } else if (type == "SendMessageResponse") {
                assert(this_.onSendMessage != null);
                this_.onSendMessage(message["requestId"], message["rescode"]);
            } else if (type == "SendMessageNotify") {
                assert(this_.onMessage != null);
                this_.onMessage(message["fromUid"], message["msg"]);
            }
        }
        var joinRequest = {
            "uid" : uid_,
            "clientinfo" : {} 
        };
        connection_.sendMessage('JoinRequest', joinRequest);
    }
    this.subscribe = function(uid) {
        if (connection_ == null) {
            logError("connection_ is null");
            return;
        }
        var request = {
            "uids" : [uid]
        };
        connection_.sendMessage("SubscribeUserRequest", request);
    }
    this.unsubscribe = function() {
        if (connection_ == null) {
            logError("connection_ is null");
            return;
        }
        var request = {
            "uids" : [uid]
        };
        connection_.sendMessage("UnsubscribeUserRequest", request);
    }
    this.sendMessage = function(uid, message) {
        if (connection_ == null) {
            logError("connection_ is null");
            return;
        }
        var request = {
            "toUid" : uid,
            "msg" : message,
        };
        connection_.sendMessage("SendMessageRequest", request);
    }
    // private:
    var destroy = function(rescode, errmsg) {
    }
}

function MessageConnection(dataChannel) {
    // private:
    var dataChannel_ = dataChannel;
    var isOpen_ = false;
    var videoTimer = null;   // 定时器
    var getVideoSizeCount = 0   // 分辨率变化时定时获取10次宽高
    var init = function() {
        logDebug("messageConnection_ is create");
        assert(dataChannel_ != null);
        dataChannel_.onmessage = function(event) {
            
            logDebug("message:" + event.data);
            let callBackData = JSON.parse(JSON.parse(event.data).msg)
            console.log("callBackData",callBackData);
            if (callBackData.msgtype == 'visitRequest') {
                if (callBackData.result === true) {
                    // 在这里接收到客户端信息
                    var subscribe = {
                        'isSubscribeVideo' : true,
                        'isSubscribeAudio' : true,
                        'videoCodecPrioritys' : [1, 2]
                    };
                    webrtcconn.sendSignalMessage(webrtcconn.peerUId_, "Subscribe", subscribe);
                    setTimeout(function(){
                        controlBox._data.videoLoaing = false
                    },1000)
                }
            }else if (
                ( 
                    callBackData.msgtype == 'reconfigRemoteResolution' || 
                    callBackData.msgtype == 'reconfigRemoteBitrate' || 
                    callBackData.msgtype == 'voiceType') 
                    && callBackData.result === true
                ) {
                    setTimeout(function(){
                        controlBox._data.videoLoaing = false     
                    },3000)
                    if (callBackData.msgtype == 'reconfigRemoteResolution') {
                        if (!videoTimer) {
                            videoTimer = window.setInterval(function() {
                                let videoBox = document.getElementById('videoBox');
                                videoBox.addEventListener('canplay', function () {
                                    controlBox._data.videoHeight = videoBox.clientHeight
                                    controlBox._data.videoWidth = videoBox.clientWidth
                                });
                                getVideoSizeCount ++
                                console.log(getVideoSizeCount)
                                if (getVideoSizeCount > 10) {
                                    window.clearInterval(videoTimer)
                                }
                            },1000)
                        }
                        
                    }          
                }
            console.log(webrtcconn,'*********************')
        }
        dataChannel_.onopen = function(event) {
            isOpen_ = true;
            logDebug("messageConnection_ is opened");
        }
        dataChannel_.onclose = function(event) {
            isOpen_ = false;
            logError("messageConnection_ is opened");
            // TODO：reconnect...
        }
    };

    init();

    // public:
    this.sendMessage = function(message) {
        if (!isOpen_) {
            logError("not isOpen, sendMessage failed");
            return;
        }
        dataChannel_.send(message);
    }
}
function guid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0,
            v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}
function WebRtcConnection(myUId, peerUId) {
    
    var myUId_ = myUId;
    var peerUId_ = peerUId;
    var localUUid_ = guid();
    var iceServer_ = {
        "iceServers": [{
            "url": "stun:stun.l.google.com:19302"
        }, {
            "url": "turn:numb.viagenie.ca",
            "username": "webrtc@live.com",
            "credential": "muazkh"
        }]
    };
    var pc_ = new RTCPeerConnection(iceServer_);  // 音视频通道
    var vstreamConnection_ = new VStreamConnection(`wss://${$baseUrl.gw}/ws?bid=vstream&aid=remotedesktop&uid=` + myUId, myUId); // 消息通道
    var messageConnection_ = null;
    var pingTimerId_ = 0; 
    var this_ = this
    this.peerUId_ = peerUId
    this.sendSignalMessage = sendSignalMessage
    this.vstreamConnection_ = vstreamConnection_
    var destroyResource = function() {
        if (pingTimerId_ != 0) {
            clearInterval(pingTimerId_);
            pingTimerId_ = 0;
        }
        if (pc_ != null) {
            pc_.close();
            pc_ = null;
        }
        if (vstreamConnection_ != null) {
            vstreamConnection_.close();
            vstreamConnection_ = null;
        }
        messageConnection_ = null;
        if (this_.onClose != null) {
            this_.onClose();
            this_.onClose = null;
        }
    }

    vstreamConnection_.onClose = function() {
        console.log('vstream connection closed')
        destroyResource();
    }
    // public:
    this.onMessage = null;
    this.destroy = function() {
        this.onClose = null;
        destroyResource();
    }
    this.sendMessage = function(message) {
        // vstreamConnection_.sendMessage(peerUId_, message);
        if (messageConnection_ == null) {
            console.error("messageConnection_ is null");
            return;
        }
        messageConnection_.sendMessage(JSON.stringify(message));
        console.info("send to:", peerUId_, " message:", message);
    }
    var init = function() {
        vstreamConnection_.onJoin = function() {
            pingTimerId_ = setInterval(function() {
                var ping = {
                    "data" : "1"
                };
                sendSignalMessage(peerUId_, "Ping", ping);
            }, 1000);
            logDebug('vstreamConnection join success...');
            let obj = new Object();
            obj.msgtype = "visitRequest";
            vstreamConnection_.sendMessage(peerUId_, JSON.stringify(obj))
            pc_.onaddstream = function(event){
                document.getElementById('remoteVideo').srcObject = event.stream;
            };
            
            pc_.onicecandidate = function(event) {
                if (event.candidate == null) {
                    logError("candidate is null");
                    return;
                }
                var candidate = {
                    'candidate' : event.candidate.candidate,
                    'sdpMid' : event.candidate.sdpMid,
                    'sdpMLineIndex' : event.candidate.sdpMLineIndex,
                };
                assert(pc_ != null);
                sendSignalMessage(peerUId_, 'ICECandidate', candidate);
            }
            pc_.ondatachannel = function(event) {
                if (messageConnection_ != null) {
                    console.log("messageConnection_ is not null, uid:", peerUId_);
                    return;
                }
                messageConnection_ = new MessageConnection(event.channel);
            };
            
            var subscribe = {
                'isSubscribeVideo' : true,
                'isSubscribeAudio' : true,
                'videoCodecPrioritys' : [1, 2]
            };
            console.log("发送订阅消息, uid:",peerUId_);
            sendSignalMessage(peerUId_, "Subscribe", subscribe);
        }
        vstreamConnection_.onUserJoin = function(uid) {
            logDebug('on user join, uid:' + uid);
        }
        vstreamConnection_.onUserLeave = function(uid) {
            logError('on user leave, uid:' + uid);
        }
        vstreamConnection_.onSendMessage = function(requestId, rescode) {
            // logDebug('on sendMessage, requestId:' + requestId + ' rescode:' + rescode);
        }
        vstreamConnection_.onMessage = function(uid, msg) {
            logDebug('on Message, uid:' + uid + ' msg:' + msg);
            assert(pc_ != null);
            var message = JSON.parse(msg);
            if (message["vstreamsignaltype"] != null) {
                onSignalMessage(uid, message["vstreamsignaltype"], message);    
            } else {
            }
        }
        vstreamConnection_.onRejected = function() {
            logError('on Rejected');
        }
        vstreamConnection_.join();
    }
    function sendSignalMessage(uid, signalType, message) {
        assert(message['vstreamuuid'] == null);
        assert(message['vstreamsignaltype'] == null);
        message['vstreamuuid'] = localUUid_;
        message['vstreamsignaltype'] = signalType;
        assert(pc_ != null);
        vstreamConnection_.sendMessage(uid, JSON.stringify(message));
    }
    function onSignalMessage(uid, signalType, message) {
        if (signalType == "ICECandidate") {
            assert(pc_ != null);
            pc_.addIceCandidate(new RTCIceCandidate(message), function() {
            }, function() {
                logError('pc add ice candidate failed');
                destroyResource();
            });
            logDebug("add candidate:" + message.candidate);
        } else if (signalType == "SDP") {
            if (message["type"] != 0) {
                logError("message type is offer");
                return;
            }
            if (pc_ == null) {
                logError("pc is null");
                return;
            }
            var sdp = {
                'type' : 'offer',
                'sdp' : message['sdp']
            };
            pc_.setRemoteDescription(new RTCSessionDescription(sdp), function() {
            }, function() {
                logError('pc set remote description failed')
                destroyResource();
            });
            pc_.createAnswer(function (ansewer) {
                pc_.setLocalDescription(ansewer, function() {
                }, function() {
                    logError('setLocalDescription failed');
                    destroyResource();
                });
                var ansewerSDP = {
                    'type' : 2,
                    'sdp' : ansewer.sdp
                };
                logDebug("ansewer sdp:" + ansewer.sdp);
                sendSignalMessage(peerUId_, "SDP", ansewerSDP);
            }, function() {
                logError('createAnswer failed');
                destroyResource();
            });
        }
    }
    
    init();
}

