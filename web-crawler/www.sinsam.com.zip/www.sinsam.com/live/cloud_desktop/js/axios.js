
function getEnv () {
  if (/local|192|www-dev.sinsam.com/i.test(location.host)) {
      return 'dev';
  } else if (/www-test.sinsam.com/i.test(location.host)) {
      return 'test';
  } else if (/www-pre.sinsam.com/i.test(location.host)) {
      return 'pre';
  } else if (/www.sinsam.com/i.test(location.host)) {
      return 'prod';
  } else {
      return 'dev'
  }
}

var $baseUrl = {
  vstream: '',
  gw: ''
}



switch(getEnv()) {
  case 'dev':
    $baseUrl.vstream = 'https://vstream-dev.vzan.com/api';
    $baseUrl.gw = 'gw-dev.vzan.com';
      break;
  case 'test':
    $baseUrl.vstream = 'https://vstream-test.vzan.com/api';
    $baseUrl.gw = 'gw-test.vzan.com';
      break;
  case 'pre':
    $baseUrl.vstream = 'https://vstream-pre.vzan.com/api';
    $baseUrl.gw = 'gw-pre.vzan.com';
      break;
  case 'prod':
    $baseUrl.vstream = 'https://vstream.vzan.com/api';
    $baseUrl.gw = 'gw.vzan.com';
      break;
  default:
    $baseUrl.vstream = 'https://vstream-dev.vzan.com/api';
    $baseUrl.gw = 'gw-dev.vzan.com';
      break;
}
//新建一个request.js
(function (win) {
    var Request = axios.create({
      timeout: 10000,
      baseURL: $baseUrl.vstream,
      headers:{
          'Content-Type':'application/x-www-form-urlencoded',
      },
    });
    Request.interceptors.request.use((config) => {
      console.log(config,'config')
      return config
    }, (err) => {
      console.log(err);
      return err;
    });
    // console.log(Request,'Request')
    Request.interceptors.response.use((response) => {
      return response.data;
    }, (err) => {
      console.log(err);
      return err;
    });

    win.$axios = Request
})(window);
