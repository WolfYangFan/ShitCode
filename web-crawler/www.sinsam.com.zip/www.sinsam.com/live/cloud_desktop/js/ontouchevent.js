var webrtcconn = null;
var remoteVideo = null; 
var binpressedclick = false;//表示是否在被按压后松开的那一次click

//单击或者双击 左键还是右键  也可拆分
function MouseClickDef(status,bleft) {
  let obj = new Object();
  obj.msgtype = "mouseClick";
  obj.status = status//single pr double 
  obj.left = bleft;//true or false 
  return obj;
}
//拖动例子  先发按下
//最后发松开 完成拖动
function MousePressLooseDef(status,bleft) {
  let obj = new Object();
  obj.msgtype = "mousePress";
  obj.left = bleft;
  obj.status = status//pressed or released
  return obj;
}
//鼠标位置
function MousePositionDef(x, y) {
  let obj = new Object();
  obj.msgtype = "mouseMove";
  obj.x = x;
  obj.y = y;
  return obj;
}

function setupTouchEvent(conn, videoel) {
  webrtcconn = conn;
  remoteVideo = videoel;
  let clientWidth = remoteVideo.clientWidth
  let clientHeight = remoteVideo.clientHeight
  // 按下
  $(document).on("touchstart", function(event) {
    let e = event || window.event || arguments.callee.caller.arguments[0];
    e.preventDefault();  //阻止默认事件
    console.log("touch down")
    let msg = null
    msg = new MousePressLooseDef("pressed", true);  //左键事件
  });
  // 抬起
  $(document).on("touchend", function(event) {
    let e = event || window.event || arguments.callee.caller.arguments[0];
    e.preventDefault();  //阻止默认事件
    console.log("touch down")
    let msg = null
    msg = new MousePressLooseDef("released", true);  //左键事件
    if(binvideoElemRange) {
      webrtcconn.sendMessage(msg);
    };
    webrtcconn.sendMessage(msg);
  });
  $(remoteVideo).on("touchstart", function(event) {
    //         console.log("进来");
    let e = event || window.event || arguments.callee.caller.arguments[0];
    e.preventDefault();  //阻止默认事件
    binvideoElemRange = true;
    let msg = new MouseClickDef("single", true);
    if(!binpressedclick&&binvideoElemRange) {
      webrtcconn.sendMessage(msg);
    }else{
      //console.log("忽略这一次click");
      binpressedclick=false;
    }
  })
  $(remoteVideo).on("touchend", function(event) {
    //         console.log("出去");
    binvideoElemRange = false;
  })
  $(remoteVideo).on("touchmove", function(event) {
    // debugger
    let e = event || window.event || arguments.callee.caller.arguments[0];
    e.preventDefault();  //阻止默认事件
    let clientX = e.originalEvent.changedTouches[0].pageX;
    let clientY = e.originalEvent.changedTouches[0].pageY;
    console.log(clientX,clientY,'clientXclientX')
    let msg = new MousePositionDef((( clientX - remoteVideo.offsetLeft)/clientWidth * 100), ((clientY - remoteVideo.offsetTop)/clientHeight * 100));
    if(binvideoElemRange) {
      webrtcconn.sendMessage(msg);
    };
  })
}
